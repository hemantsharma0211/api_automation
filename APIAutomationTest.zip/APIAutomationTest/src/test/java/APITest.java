import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Map;

import static io.restassured.RestAssured.given;

public class APITest {

    private static final String EXCEL_FILE_PATH = "src/test/java/testdata.xlsx";
    private static final String SHEET_NAME = "Sheet1";

    @DataProvider(name = "excelData")
    public Object[][] getExcelData() {
        // Assuming there is 1 row of data excluding header row
        return new Object[][] {
                { ExcelUtils.getDataFromExcel(EXCEL_FILE_PATH, SHEET_NAME, 1) }
        };
    }

    @Test(dataProvider = "excelData")
    public void testGetEndpoint(Map<String, String> testData) {
        String baseUrl = testData.get("BaseURL");

        Response response = given()
                .when()
                .get(baseUrl)
                .then()
                .statusCode(200)
                .extract()
                .response();

        // Perform assertions based on response
        System.out.println(response.asString());
    }
}

