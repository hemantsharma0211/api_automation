import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ExcelUtils {

    public static Map<String, String> getDataFromExcel(String filePath, String sheetName, int rowNum) {
        Map<String, String> data = new HashMap<>();
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet(sheetName);
            Row row = sheet.getRow(rowNum);

            for (Cell cell : row) {
                int columnIndex = cell.getColumnIndex();
                String columnHeader = sheet.getRow(0).getCell(columnIndex).getStringCellValue();
                String cellValue = cell.getCellType() == CellType.STRING ? cell.getStringCellValue() :
                        cell.getCellType() == CellType.NUMERIC ? String.valueOf(cell.getNumericCellValue()) : "";
                data.put(columnHeader, cellValue);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }
}

