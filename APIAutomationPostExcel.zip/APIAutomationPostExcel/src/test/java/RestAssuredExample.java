//import io.restassured.RestAssured;
//import io.restassured.http.ContentType;
//import io.restassured.response.Response;
//
//import java.io.IOException;
//import java.util.Map;
//
//public class RestAssuredExample {
//    public static void main(String[] args) {
//        String excelFilePath = "src/test/java/posttestdata.xlsx"; // Adjust the path
//        String sheetName = "Sheet1";
//
//        try {
//            Map<String, String> params = ExcelUtils.getParameters(excelFilePath, sheetName);
//            String title = params.get("title");
//            String body = params.get("body");
//            String userId = params.get("userId");
//
//            String jsonBody = String.format("{\"title\": \"%s\", \"body\": \"%s\", \"userId\": \"%s\"}", title, body, userId);
//
//            Response response = RestAssured
//                    .given()
//                    .contentType(ContentType.JSON.withCharset("UTF-8"))
//                    .body(jsonBody)
//                    .when()
//                    .post("https://jsonplaceholder.typicode.com/posts");
//
//            System.out.println("Response Status Code: " + response.getStatusCode());
//            System.out.println("Response Body: " + response.getBody().asString());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//}

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.JSONObject;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.Map;

import static org.hamcrest.Matchers.equalTo;

public class RestAssuredExample {
    public static void main(String[] args) {
        String excelFilePath = "src/test/java/posttestdata.xlsx"; // Adjust the path
        String sheetName = "Sheet1";

        // Initialize Extent Reports
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("extentReport.html");
        htmlReporter.config().setTheme(Theme.STANDARD);
        htmlReporter.config().setDocumentTitle("API Test Report");
        htmlReporter.config().setReportName("RestAssured API Testing");

        ExtentReports extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        ExtentTest test = extent.createTest("POST API Test", "Test to POST data to JSONPlaceholder");

        try {
            Map<String, String> params = ExcelUtils.getParameters(excelFilePath, sheetName);
            String title = params.get("title");
            String body = params.get("body");
            String userId = params.get("userId");

            JSONObject jsonBody = new JSONObject();
            jsonBody.put("title", title);
            jsonBody.put("body", body);
            jsonBody.put("userId", userId);

            test.info("JSON Body: " + jsonBody.toString());

            Response response = RestAssured
                    .given()
                    .contentType(ContentType.JSON.withCharset("UTF-8"))
                    .body(jsonBody.toString())
                    .when()
                    .post("https://jsonplaceholder.typicode.com/posts");

            int statusCode = response.getStatusCode();
            String responseBody = response.getBody().asString();

            test.info("Response Status Code: " + statusCode);
            test.info("Response Body: " + responseBody);

            // Assert the response status code
            if (statusCode == 201) {
                test.pass("Post was successful.");
            } else {
                test.fail("Post failed. Status Code: " + statusCode);
            }

            // Additional assertions on the response body
            try {
                response.then().assertThat().statusCode(201)
                        .body("title", equalTo(title))
                        .body("body", equalTo(body));

                test.pass("Response body contains expected values.");
            } catch (AssertionError e) {
                test.fail("Response body did not contain expected values: " + e.getMessage());
            }

        } catch (IOException e) {
            test.fail("Error reading the Excel file: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            test.fail("An unexpected error occurred: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Write the report to the specified file
            extent.flush();
            // Automatically open the report after the tests are run
            openReport("extentReport.html");
        }
    }

    // Method to open the report automatically
    public static void openReport(String filePath) {
        try {
            File htmlFile = new File(filePath);
            if (htmlFile.exists()) {
                Desktop.getDesktop().browse(htmlFile.toURI());
            } else {
                System.err.println("Report file does not exist: " + filePath);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

